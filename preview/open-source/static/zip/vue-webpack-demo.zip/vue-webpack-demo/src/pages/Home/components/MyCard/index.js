import MyCard from './MyCard';

export default MyCard;