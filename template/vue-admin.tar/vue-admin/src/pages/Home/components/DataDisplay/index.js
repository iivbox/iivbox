import DataDisplay from './DataDisplay'

export default DataDisplay