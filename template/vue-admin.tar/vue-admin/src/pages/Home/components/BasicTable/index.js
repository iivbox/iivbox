import BasicTable from './BasicTable'

export default BasicTable