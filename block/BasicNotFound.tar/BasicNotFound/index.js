import BasicNotFound from './BasicNotFound'

export default BasicNotFound