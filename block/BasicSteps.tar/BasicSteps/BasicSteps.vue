<template>
  <div class="basic-steps">
      <BasicContainer>
        <template>
            <Steps :current="1">
                <Step title="已完成" content="这里是该步骤的描述信息"></Step>
                <Step title="进行中" content="这里是该步骤的描述信息"></Step>
                <Step title="待进行" content="这里是该步骤的描述信息"></Step>
                <Step title="待进行" content="这里是该步骤的描述信息"></Step>
            </Steps>
        </template>
      </BasicContainer>
  </div>
</template>
<script>
import BasicContainer from '@vue-materials/basic-container'
export default {
    components: { BasicContainer },
}
</script>

<style lang="less" scoped>
  .basic-steps{
    
  }
</style>
